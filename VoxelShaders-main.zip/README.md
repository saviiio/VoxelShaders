# VoxelShaders

Shaderpack Iris com pipeline baseado em gbuffers + composite para iluminação voxel.

## Estrutura

- `shaders/lib/*.glsl`: funções compartilhadas (normal encode/decode, iluminação).
- `shaders/programs/*.vsh|*.fsh`: implementação principal dos passes.
- `shaders/gbuffers_*.vsh|*.fsh`: entradas de programa Iris que incluem os arquivos principais.
- `shaders/composite.vsh|composite.fsh`: pass de iluminação/composição.
- `shaders/final.vsh|final.fsh`: pass final de correção de cor/gamma.

## Observações Iris

- Uso de `#version 330 compatibility`.
- Uso de `/* RENDERTARGETS: ... */` nos passes necessários.
- Escrita de dados extras em `colortex1` e `colortex2` para uso no `composite`.
- `particles.ordering=mixed` habilitado em `shaders.properties` para suportar o pass translúcido de partículas.
- `const float ambientOcclusionLevel = 0.0;` desativa a oclusão ambiente vanilla no Iris.

## Extensões de estágios no Iris

- Vertex: `.vsh`
- Fragment: `.fsh`
- Geometry: `.gsh`
- Compute: `.csh`
- Tessellation: `.tcs` e `.tes`


## Ajustes feitos

- Sombra direta ligada ao shadow map do Iris.
- GI/indireta baseada em voxels visíveis no G-buffer.
- Cavernas recebem menos céu e ficam bem mais escuras.
